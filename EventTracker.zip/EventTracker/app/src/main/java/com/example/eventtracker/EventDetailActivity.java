package com.example.eventtracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EventDetailActivity extends AppCompatActivity {
    private EditText titleInput, dateInput, timeInput, notesInput;
    private Button saveButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        titleInput = findViewById(R.id.etEventTitle);
        dateInput = findViewById(R.id.etEventDate);
        timeInput = findViewById(R.id.etEventTime);
        notesInput = findViewById(R.id.etNotes);
        saveButton = findViewById(R.id.btnSave);
        deleteButton = findViewById(R.id.btnDelete);

        saveButton.setOnClickListener(v ->
                Toast.makeText(this, "Event saved (demo)", Toast.LENGTH_SHORT).show()
        );

        deleteButton.setOnClickListener(v ->
                Toast.makeText(this, "Event deleted (demo)", Toast.LENGTH_SHORT).show()
        );
    }
}
