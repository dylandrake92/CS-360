package com.example.eventtracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class EventsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private DatabaseHelper dbHelper;
    private GridView gridEvents;
    private Button addEventButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        dbHelper = new DatabaseHelper(this);
        gridEvents = findViewById(R.id.gridEvents);
        addEventButton = findViewById(R.id.btnAddEvent);

        loadEvents();

        addEventButton.setOnClickListener(v -> {
            startActivity(new Intent(EventsActivity.this, EventDetailActivity.class));
            sendSmsNotification("New event created in Event Tracker!");
        });
    }

    // -------------------------------
    // Load Events from SQLite (READ)
    // -------------------------------
    private void loadEvents() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM events", null);
        ArrayList<String> events = new ArrayList<>();

        while (cursor.moveToNext()) {
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String details = cursor.getString(3);
            events.add(name + "\n" + date + "\n" + details);
        }

        cursor.close();
        db.close();

        if (events.isEmpty()) {
            events.add("No events yet.\nTap 'Add Event' to create one.");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, events);
        gridEvents.setAdapter(adapter);
    }

    // ---------------------------------
    // SMS Notification Functionality
    // ---------------------------------
    private void sendSmsNotification(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5554", null, message, null, null); // emulator phone number
                Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsNotification("SMS permission granted. Notifications enabled.");
            } else {
                Toast.makeText(this, "SMS permission denied. App will continue without SMS alerts.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents(); // reload events each time returning from EventDetailActivity
    }
}
